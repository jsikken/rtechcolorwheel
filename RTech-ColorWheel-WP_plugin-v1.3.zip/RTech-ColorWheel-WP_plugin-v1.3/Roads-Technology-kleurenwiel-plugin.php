<?php
/*
Plugin Name: Roads Technology Kleurenwiel
Plugin URI: https://jsikken.github.io/rtechcolorwheel/
Description: Gebruik de shortcodes: [kleurenwiel] en/of [kleurenwiel-advance] om het kleurenwiel te genereren op je pagina. 
Version: 1.3
Author: Joppe Sikken
Author URI: https://github.com/jsikken/rtechcolorwheel
*/

function kleurenwiel_enqueue_scripts() {
    // Enqueue scripts and styles for the basic kleurenwiel
    wp_enqueue_script('roads-technology-kleurenwiel-script', plugin_dir_url(__FILE__) . 'js/script.js', array(), '1.0', true);
    wp_enqueue_style('roads-technology-kleurenwiel-style', plugin_dir_url(__FILE__) . 'css/style.css');
    
    // Enqueue scripts and styles for the advanced kleurenwiel
    wp_enqueue_script('roads-technology-kleurenwiel-advance-script', plugin_dir_url(__FILE__) . 'js/script-advance.js', array(), '1.0', true);
    wp_enqueue_style('roads-technology-kleurenwiel-advance-style', plugin_dir_url(__FILE__) . 'css/style-advance.css');
}
add_action('wp_enqueue_scripts', 'kleurenwiel_enqueue_scripts');

function kleurenwiel_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'plugin.html';
    return ob_get_clean();
}
add_shortcode('kleurenwiel', 'kleurenwiel_shortcode');

function kleurenwiel_advance_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'plugin-advance.html';
    return ob_get_clean();
}
add_shortcode('kleurenwiel-advance', 'kleurenwiel_advance_shortcode');
?>