<?php
/*
Plugin Name: Roads Technology Kleurenwiel
Plugin URI: https://jsikken.github.io/rtechcolorwheel/
Description: Gebruik de shortcode: [kleurenwiel] om het kleurenwiel te genereren op je pagina. 
Version: 1.4
Author: Joppe Sikken
Author URI: https://github.com/jsikken/rtechcolorwheel
*/

function kleurenwiel_enqueue_scripts() {
    wp_enqueue_script('roads-technology-kleurenwiel-script', plugin_dir_url(__FILE__) . 'js/script.js', array(), '1.0', true);
    wp_enqueue_style('roads-technology-kleurenwiel-style', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('wp_enqueue_scripts', 'kleurenwiel_enqueue_scripts');

function kleurenwiel_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'plugin.html';
    return ob_get_clean();
}
add_shortcode('kleurenwiel', 'kleurenwiel_shortcode');